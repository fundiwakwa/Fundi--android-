FUNDI ANDROID APK PROJECT

This project wraps the existing live Fundi website in a simple Android app.
It uses the existing Cloudflare Pages URL:
https://fundiapp2026.pages.dev/

IMPORTANT
- This is a WebView wrapper, not a rewrite of Fundi.
- The app needs internet access and the live website must remain online.
- Supabase remains the existing backend.
- The Netlify test site is not used because it was password-protected.
- First build is a debug APK for testing. It is signed with Android's debug key.
- Before public distribution and future seamless upgrades, create and securely keep
  a permanent signing key. Do not lose it; future APK updates must use the same key.

HOW TO BUILD WITHOUT PAYING FOR A BUILD SERVICE
1. Create a free GitHub account and a new empty repository named Fundi-Android.
2. Upload the contents of this folder to the repository (not the outer folder).
3. Open the repository's Actions tab.
4. Select "Build Fundi Android APK" and click "Run workflow", or push to main.
5. When the workflow finishes, open the run and download the artifact named
   Fundi-Android-APK. Extract it to get app-debug.apk.
6. Transfer app-debug.apk to your Android phone and open it to install.
   Android may ask you to allow installation from that source.

The first APK is for testing only. Do not distribute it widely until we have
tested login, booking, provider flows, file uploads, notifications, and navigation.

If the app's live URL changes, update fundiUrl in MainActivity.kt.
